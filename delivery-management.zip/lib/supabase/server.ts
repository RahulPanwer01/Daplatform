import { createClient } from "@supabase/supabase-js"
import { cookies } from "next/headers"

export function createServerClient() {
  const cookieStore = cookies()

  // Check if Supabase environment variables are available
  const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY

  if (!supabaseUrl || !supabaseServiceKey) {
    // Return a mock client if credentials aren't available
    return {
      auth: {
        getSession: async () => ({ data: { session: null } }),
      },
      from: () => ({
        select: () => ({
          order: () => ({
            limit: () => ({ data: [] }),
          }),
        }),
      }),
    } as ReturnType<typeof createClient>
  }

  return createClient(supabaseUrl, supabaseServiceKey, {
    cookies: {
      get(name: string) {
        return cookieStore.get(name)?.value
      },
    },
  })
}
