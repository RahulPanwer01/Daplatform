import { createClient } from "@supabase/supabase-js"

// Create a mock client for environments where Supabase credentials aren't available
const createMockClient = () => {
  return {
    auth: {
      signInWithPassword: async () => ({ data: {}, error: new Error("Mock Supabase client - not connected") }),
      signOut: async () => ({ error: null }),
      getSession: async () => ({ data: { session: null } }),
      onAuthStateChange: () => ({ data: { subscription: { unsubscribe: () => {} } } }),
    },
    from: () => ({
      select: () => ({
        eq: () => ({
          single: async () => ({ data: null, error: new Error("Mock Supabase client - not connected") }),
        }),
        order: () => ({
          limit: () => ({ data: [] }),
        }),
      }),
      insert: () => ({ error: new Error("Mock Supabase client - not connected") }),
      update: () => ({ eq: () => ({ error: new Error("Mock Supabase client - not connected") }) }),
      delete: () => ({ eq: () => ({ error: new Error("Mock Supabase client - not connected") }) }),
    }),
    storage: {
      from: () => ({
        upload: async () => ({ data: null, error: new Error("Mock Supabase client - not connected") }),
        getPublicUrl: () => ({ data: { publicUrl: "" } }),
      }),
    },
    channel: () => ({
      on: () => ({
        subscribe: () => ({
          unsubscribe: () => {},
        }),
      }),
    }),
  }
}

// Check if Supabase environment variables are available
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY

// Create a client only if both URL and key are available, otherwise use mock
export const supabase =
  supabaseUrl && supabaseAnonKey
    ? createClient(supabaseUrl, supabaseAnonKey)
    : (createMockClient() as ReturnType<typeof createClient>)

// Helper to check if we have a real Supabase connection
export const hasSupabaseConnection = () =>
  !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
