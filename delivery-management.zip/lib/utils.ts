import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"
import { format, formatDistanceToNow as formatDistanceToNowFn } from "date-fns"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatDate(date: string | Date, formatStr = "PPP"): string {
  if (!date) return "N/A"
  return format(new Date(date), formatStr)
}

export function formatDistanceToNow(date: string | Date): string {
  if (!date) return "N/A"
  return formatDistanceToNowFn(new Date(date), { addSuffix: true })
}

export function generateId(prefix = ""): string {
  return `${prefix}${Math.random().toString(36).substring(2, 10)}`
}

export function getInitials(name: string): string {
  if (!name) return "NA"
  return name
    .split(" ")
    .map((part) => part[0])
    .join("")
    .toUpperCase()
    .substring(0, 2)
}

export function getStatusColor(status: string): string {
  switch (status) {
    case "pending":
      return "bg-yellow-100 text-yellow-800"
    case "assigned":
      return "bg-blue-100 text-blue-800"
    case "in-progress":
      return "bg-purple-100 text-purple-800"
    case "delivered":
      return "bg-green-100 text-green-800"
    case "cancelled":
      return "bg-red-100 text-red-800"
    case "issue":
      return "bg-orange-100 text-orange-800"
    default:
      return "bg-gray-100 text-gray-800"
  }
}

export function parseExcelDate(serialDate: number): Date {
  // Excel dates are number of days since 1/1/1900
  // JavaScript dates are milliseconds since 1/1/1970
  const daysSince1900 = serialDate
  const date = new Date(1900, 0, 1)
  date.setDate(date.getDate() + daysSince1900 - 2) // -2 to adjust for Excel's leap year bug
  return date
}
