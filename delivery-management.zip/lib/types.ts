export type Role = "admin" | "driver"

export interface User {
  id: string
  email: string
  role: Role
  name: string
}

export interface Driver {
  driver_id: string
  name: string
  email: string
  phone: string
  status: "active" | "inactive"
  created_at: string
  current_location?: {
    lat: number
    lng: number
    address?: string
  }
  last_location_update?: string
}

export interface Order {
  order_id: string
  customer_name: string
  customer_address: string
  customer_phone: string
  delivery_deadline: string
  status: "pending" | "assigned" | "in-progress" | "delivered" | "cancelled" | "issue"
  driver_id?: string
  created_at: string
  delivery_notes?: string
  package_count: number
  priority: "low" | "normal" | "high"
  completed_at?: string
}

export interface Package {
  package_id: string
  order_id: string
  name: string
  weight?: number
  dimensions?: string
  special_instructions?: string
  created_at: string
}

export interface ProofOfDelivery {
  pod_id: string
  order_id: string
  photo_url?: string
  signature_url?: string
  notes?: string
  location?: {
    lat: number
    lng: number
    address?: string
  }
  created_at: string
  created_by: string
}

export interface DeliveryHistory {
  history_id: string
  order_id: string
  previous_status?: string
  new_status: string
  changed_at: string
  changed_by?: string
  notes?: string
}

export interface BulkUploadLog {
  upload_id: string
  filename: string
  uploaded_by: string
  record_count: number
  success_count: number
  error_count: number
  upload_date: string
  status: "processing" | "completed" | "failed"
}

export interface BulkUploadRow {
  customer_name: string
  customer_address: string
  customer_phone: string
  delivery_deadline: string
  delivery_notes?: string
  package_count?: number
  priority?: "low" | "normal" | "high"
  package_name?: string
  package_weight?: number
  package_dimensions?: string
  special_instructions?: string
}

export interface Delivery {
  id: string
  packageInfo: {
    id: string
    name: string
  }
  recipient: {
    name: string
    address: string
    phone: string
  }
  driverName: string
  driverId: string
  status: "assigned" | "in-progress" | "delivered" | "issue" | "cancelled"
  notes?: string
  createdAt: string
  updatedAt: string
  completedAt?: string
  location?: {
    lat: number
    lng: number
  }
}
