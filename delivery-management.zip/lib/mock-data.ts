import type { Delivery, Driver, Package } from "./types"

// Generate a random ID
const generateId = () => Math.random().toString(36).substring(2, 10)

// Generate a random date within the last 7 days
const generateRecentDate = (daysAgo = 7) => {
  const date = new Date()
  date.setDate(date.getDate() - Math.floor(Math.random() * daysAgo))
  return date.toISOString()
}

// Mock drivers data
export const mockDrivers: Driver[] = [
  {
    id: generateId(),
    name: "John Smith",
    status: "active",
    currentLocation: "Downtown, Main St",
    location: { lat: 40.7128, lng: -74.006 },
    activeDeliveries: 3,
    completedDeliveries: 128,
  },
  {
    id: generateId(),
    name: "Sarah Johnson",
    status: "active",
    currentLocation: "Westside, Oak Ave",
    location: { lat: 40.7228, lng: -74.016 },
    activeDeliveries: 2,
    completedDeliveries: 95,
  },
  {
    id: generateId(),
    name: "Michael Brown",
    status: "inactive",
    currentLocation: "North End, Pine St",
    location: { lat: 40.7328, lng: -74.026 },
    activeDeliveries: 0,
    completedDeliveries: 67,
  },
  {
    id: generateId(),
    name: "Emily Davis",
    status: "active",
    currentLocation: "Eastside, Maple Rd",
    location: { lat: 40.7428, lng: -74.036 },
    activeDeliveries: 4,
    completedDeliveries: 112,
  },
  {
    id: generateId(),
    name: "Robert Wilson",
    status: "active",
    currentLocation: "Southside, Elm St",
    location: { lat: 40.7028, lng: -73.996 },
    activeDeliveries: 1,
    completedDeliveries: 43,
  },
]

// Mock packages data
export const mockPackages: Package[] = [
  {
    id: generateId(),
    name: "Electronics Package",
    recipient: {
      name: "Alex Thompson",
      address: "123 Main St, Apt 4B, New York, NY 10001",
      phone: "(212) 555-1234",
    },
    weight: "2.5 kg",
    dimensions: "30x20x15 cm",
    createdAt: generateRecentDate(),
    deliveryId: generateId(),
  },
  {
    id: generateId(),
    name: "Office Supplies",
    recipient: {
      name: "Morgan Stanley",
      address: "456 Business Ave, Suite 200, New York, NY 10002",
      phone: "(212) 555-5678",
    },
    weight: "5 kg",
    dimensions: "40x30x20 cm",
    createdAt: generateRecentDate(),
    deliveryId: generateId(),
  },
  {
    id: generateId(),
    name: "Clothing Items",
    recipient: {
      name: "Jamie Rodriguez",
      address: "789 Fashion Blvd, New York, NY 10003",
      phone: "(212) 555-9012",
    },
    weight: "1 kg",
    dimensions: "25x20x10 cm",
    createdAt: generateRecentDate(),
  },
  {
    id: generateId(),
    name: "Books Package",
    recipient: {
      name: "Taylor Williams",
      address: "321 Reader St, Brooklyn, NY 11201",
      phone: "(718) 555-3456",
    },
    weight: "3 kg",
    dimensions: "35x25x10 cm",
    createdAt: generateRecentDate(),
    deliveryId: generateId(),
  },
  {
    id: generateId(),
    name: "Kitchen Appliance",
    recipient: {
      name: "Jordan Lee",
      address: "654 Cooking Ave, Queens, NY 11101",
      phone: "(718) 555-7890",
    },
    weight: "8 kg",
    dimensions: "50x40x30 cm",
    createdAt: generateRecentDate(),
  },
  {
    id: generateId(),
    name: "Fragile Glassware",
    recipient: {
      name: "Casey Martin",
      address: "987 Delicate Ln, Bronx, NY 10451",
      phone: "(718) 555-2345",
    },
    weight: "4 kg",
    dimensions: "45x35x25 cm",
    createdAt: generateRecentDate(),
  },
  {
    id: generateId(),
    name: "Sports Equipment",
    recipient: {
      name: "Riley Johnson",
      address: "159 Athletic Dr, Staten Island, NY 10301",
      phone: "(718) 555-6789",
    },
    weight: "6 kg",
    dimensions: "70x30x20 cm",
    createdAt: generateRecentDate(),
    deliveryId: generateId(),
  },
]

// Mock deliveries data
export const mockDeliveries: Delivery[] = [
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Electronics Package",
    },
    recipient: {
      name: "Alex Thompson",
      address: "123 Main St, Apt 4B, New York, NY 10001",
      phone: "(212) 555-1234",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "in-progress",
    notes: "Please handle with care. Fragile electronics inside.",
    createdAt: generateRecentDate(),
    updatedAt: generateRecentDate(1),
    location: { lat: 40.7128, lng: -74.006 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Office Supplies",
    },
    recipient: {
      name: "Morgan Stanley",
      address: "456 Business Ave, Suite 200, New York, NY 10002",
      phone: "(212) 555-5678",
    },
    driverName: "Sarah Johnson",
    driverId: mockDrivers[1].id,
    status: "assigned",
    createdAt: generateRecentDate(),
    updatedAt: generateRecentDate(1),
    location: { lat: 40.7228, lng: -74.016 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Books Package",
    },
    recipient: {
      name: "Taylor Williams",
      address: "321 Reader St, Brooklyn, NY 11201",
      phone: "(718) 555-3456",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "delivered",
    createdAt: generateRecentDate(14),
    updatedAt: generateRecentDate(7),
    completedAt: generateRecentDate(7),
    location: { lat: 40.6782, lng: -73.9442 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Sports Equipment",
    },
    recipient: {
      name: "Riley Johnson",
      address: "159 Athletic Dr, Staten Island, NY 10301",
      phone: "(718) 555-6789",
    },
    driverName: "Emily Davis",
    driverId: mockDrivers[3].id,
    status: "issue",
    notes: "Customer not available. Attempted delivery twice.",
    createdAt: generateRecentDate(),
    updatedAt: generateRecentDate(1),
    location: { lat: 40.5795, lng: -74.1502 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Furniture Delivery",
    },
    recipient: {
      name: "Sam Wilson",
      address: "753 Comfort St, Manhattan, NY 10004",
      phone: "(212) 555-8901",
    },
    driverName: "Robert Wilson",
    driverId: mockDrivers[4].id,
    status: "in-progress",
    createdAt: generateRecentDate(),
    updatedAt: generateRecentDate(1),
    location: { lat: 40.7033, lng: -74.017 },
  },
]

// Mock delivery history (includes more completed deliveries)
export const mockDeliveryHistory: Delivery[] = [
  ...mockDeliveries,
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Computer Monitor",
    },
    recipient: {
      name: "Jordan Blake",
      address: "852 Tech Ave, Manhattan, NY 10005",
      phone: "(212) 555-2345",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "delivered",
    createdAt: generateRecentDate(30),
    updatedAt: generateRecentDate(28),
    completedAt: generateRecentDate(28),
    location: { lat: 40.7051, lng: -74.0092 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Gourmet Food Basket",
    },
    recipient: {
      name: "Taylor Swift",
      address: "963 Melody Ln, Brooklyn, NY 11202",
      phone: "(718) 555-6789",
    },
    driverName: "Sarah Johnson",
    driverId: mockDrivers[1].id,
    status: "delivered",
    createdAt: generateRecentDate(25),
    updatedAt: generateRecentDate(23),
    completedAt: generateRecentDate(23),
    location: { lat: 40.6782, lng: -73.9442 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Art Supplies",
    },
    recipient: {
      name: "Alex Morgan",
      address: "741 Creative St, Queens, NY 11102",
      phone: "(718) 555-0123",
    },
    driverName: "Emily Davis",
    driverId: mockDrivers[3].id,
    status: "cancelled",
    createdAt: generateRecentDate(20),
    updatedAt: generateRecentDate(18),
    location: { lat: 40.7282, lng: -73.7949 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Fitness Equipment",
    },
    recipient: {
      name: "Chris Evans",
      address: "159 Muscle Ave, Bronx, NY 10452",
      phone: "(718) 555-4567",
    },
    driverName: "Michael Brown",
    driverId: mockDrivers[2].id,
    status: "delivered",
    createdAt: generateRecentDate(15),
    updatedAt: generateRecentDate(13),
    completedAt: generateRecentDate(13),
    location: { lat: 40.8448, lng: -73.8648 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Gardening Supplies",
    },
    recipient: {
      name: "Robin Green",
      address: "357 Plant St, Staten Island, NY 10302",
      phone: "(718) 555-8901",
    },
    driverName: "Robert Wilson",
    driverId: mockDrivers[4].id,
    status: "delivered",
    createdAt: generateRecentDate(10),
    updatedAt: generateRecentDate(8),
    completedAt: generateRecentDate(8),
    location: { lat: 40.5795, lng: -74.1502 },
  },
]

// Mock driver deliveries (for the driver panel)
export const mockDriverDeliveries: Delivery[] = [
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Electronics Package",
    },
    recipient: {
      name: "Alex Thompson",
      address: "123 Main St, Apt 4B, New York, NY 10001",
      phone: "(212) 555-1234",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "in-progress",
    notes: "Please handle with care. Fragile electronics inside.",
    createdAt: generateRecentDate(),
    updatedAt: generateRecentDate(1),
    location: { lat: 40.7128, lng: -74.006 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Medical Supplies",
    },
    recipient: {
      name: "Dr. Sarah Chen",
      address: "789 Health Ave, Suite 300, New York, NY 10016",
      phone: "(212) 555-9876",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "assigned",
    notes: "Priority delivery. Medical supplies needed urgently.",
    createdAt: generateRecentDate(),
    updatedAt: generateRecentDate(),
    location: { lat: 40.7168, lng: -73.986 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Gourmet Food Delivery",
    },
    recipient: {
      name: "James Wilson",
      address: "456 Culinary Blvd, New York, NY 10012",
      phone: "(212) 555-5432",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "assigned",
    notes: "Temperature-sensitive items. Deliver promptly.",
    createdAt: generateRecentDate(),
    updatedAt: generateRecentDate(),
    location: { lat: 40.7248, lng: -73.996 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Books Package",
    },
    recipient: {
      name: "Taylor Williams",
      address: "321 Reader St, Brooklyn, NY 11201",
      phone: "(718) 555-3456",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "delivered",
    createdAt: generateRecentDate(3),
    updatedAt: generateRecentDate(2),
    completedAt: generateRecentDate(2),
    location: { lat: 40.6782, lng: -73.9442 },
  },
  {
    id: generateId(),
    packageInfo: {
      id: generateId(),
      name: "Computer Monitor",
    },
    recipient: {
      name: "Jordan Blake",
      address: "852 Tech Ave, Manhattan, NY 10005",
      phone: "(212) 555-2345",
    },
    driverName: "John Smith",
    driverId: mockDrivers[0].id,
    status: "delivered",
    createdAt: generateRecentDate(2),
    updatedAt: generateRecentDate(1),
    completedAt: generateRecentDate(1),
    location: { lat: 40.7051, lng: -74.0092 },
  },
]
