import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Package2, Truck } from "lucide-react"
import { AuthForm } from "@/components/auth/auth-form"
import { TestLoginCredentials } from "@/components/auth/test-login-credentials"

export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-blue-50 to-blue-100 dark:from-slate-900 dark:to-slate-800">
      <div className="container max-w-6xl px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold tracking-tight sm:text-5xl mb-4">Delivery Management System</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Real-time delivery tracking and management for admins and drivers
          </p>
        </div>

        <AuthForm />

        {/* Add the TestLoginCredentials component */}
        <div className="mt-6">
          <TestLoginCredentials />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-3xl mx-auto mt-8">
          <Card className="transition-all hover:shadow-lg">
            <CardHeader className="text-center">
              <div className="mx-auto bg-primary/10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-2">
                <Package2 className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Admin Panel</CardTitle>
              <CardDescription>Manage deliveries, packages, and drivers</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground">
                Access the dashboard to view real-time delivery status, assign packages to drivers, and manage your
                delivery operations.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button asChild size="lg" className="w-full">
                <Link href="/admin">Access Admin Panel</Link>
              </Button>
            </CardFooter>
          </Card>

          <Card className="transition-all hover:shadow-lg">
            <CardHeader className="text-center">
              <div className="mx-auto bg-primary/10 p-4 rounded-full w-16 h-16 flex items-center justify-center mb-2">
                <Truck className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Driver Panel</CardTitle>
              <CardDescription>Manage your assigned deliveries</CardDescription>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-muted-foreground">
                View your assigned deliveries, update delivery status, and share your location in real-time with the
                admin.
              </p>
            </CardContent>
            <CardFooter className="flex justify-center">
              <Button asChild size="lg" variant="outline" className="w-full">
                <Link href="/driver">Access Driver Panel</Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  )
}
