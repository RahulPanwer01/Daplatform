"use client"

import { useState, useEffect } from "react"
import { DriverDashboard } from "@/components/driver/driver-dashboard"
import { useAuth } from "@/components/auth/auth-provider"
import type { Order } from "@/lib/types"

export default function DriverPage() {
  const { user } = useAuth()
  const [orders, setOrders] = useState<Order[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // For demo purposes, we'll use mock data
    const mockOrders = [
      {
        order_id: "ORD002",
        customer_name: "Morgan Stanley",
        customer_address: "456 Business Ave, New York, NY 10002",
        customer_phone: "(212) 555-5678",
        delivery_deadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
        status: "assigned",
        driver_id: "DRV001",
        created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        delivery_notes: "Signature required",
        package_count: 2,
        priority: "high",
      },
      {
        order_id: "ORD003",
        customer_name: "Jamie Rodriguez",
        customer_address: "789 Fashion Blvd, New York, NY 10003",
        customer_phone: "(212) 555-9012",
        delivery_deadline: new Date().toISOString(),
        status: "in-progress",
        driver_id: "DRV002",
        created_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        delivery_notes: "Call before delivery",
        package_count: 1,
        priority: "normal",
      },
      {
        order_id: "ORD004",
        customer_name: "Taylor Williams",
        customer_address: "321 Reader St, Brooklyn, NY 11201",
        customer_phone: "(718) 555-3456",
        delivery_deadline: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        status: "delivered",
        driver_id: "DRV001",
        created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        delivery_notes: null,
        package_count: 1,
        priority: "normal",
        completed_at: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(),
      },
    ]

    // Filter orders based on the logged-in driver
    const driverStr = localStorage.getItem("driver")
    if (driverStr) {
      const driver = JSON.parse(driverStr)
      const driverId = driver.driver_id

      // Filter orders for this driver
      const filteredOrders = mockOrders.filter(
        (order) =>
          order.driver_id === driverId ||
          // For the second driver, show the in-progress order
          (driverId === "DRV002" && order.order_id === "ORD003"),
      )

      setOrders(filteredOrders)
    } else {
      setOrders([])
    }

    setIsLoading(false)
  }, [user])

  return <DriverDashboard orders={orders} isLoading={isLoading} />
}
