"use client"

import type React from "react"
import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { DriverHeader } from "@/components/driver/driver-header"
import { useAuth } from "@/components/auth/auth-provider"

export default function DriverLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { role, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // For testing purposes, we'll be more permissive
    if (!isLoading && role !== "driver") {
      // Check if we have driver data in localStorage even if the auth context hasn't loaded it yet
      const driverStr = localStorage.getItem("driver")
      if (!driverStr) {
        router.push("/")
      }
    }
  }, [isLoading, role, router])

  if (isLoading) {
    return <div>Loading...</div>
  }

  // For testing, we'll allow access even if the auth context hasn't fully loaded
  const driverStr = localStorage.getItem("driver")
  if (role !== "driver" && !driverStr) {
    return null
  }

  return (
    <div className="min-h-screen flex flex-col">
      <DriverHeader />
      <main className="flex-1">{children}</main>
    </div>
  )
}
