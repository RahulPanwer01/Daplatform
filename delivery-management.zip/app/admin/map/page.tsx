import { DeliveryMap } from "@/components/admin/delivery-map"

export default function MapPage() {
  return <DeliveryMap />
}
