"use client"

import { useEffect, useState } from "react"
import { AdminDashboard } from "@/components/admin/admin-dashboard"

export default function AdminPage() {
  const [orders, setOrders] = useState([])
  const [stats, setStats] = useState({
    totalOrders: 0,
    pendingOrders: 0,
    inProgressOrders: 0,
    deliveredOrders: 0,
    activeDrivers: 0,
    totalDrivers: 0,
  })

  useEffect(() => {
    // For demo purposes, we'll use mock data
    const mockOrders = [
      {
        order_id: "ORD001",
        customer_name: "Alex Thompson",
        customer_address: "123 Main St, New York, NY 10001",
        customer_phone: "(212) 555-1234",
        delivery_deadline: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString(),
        status: "pending",
        driver_id: null,
        created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        delivery_notes: "Leave at front door",
        package_count: 1,
        priority: "normal",
      },
      {
        order_id: "ORD002",
        customer_name: "Morgan Stanley",
        customer_address: "456 Business Ave, New York, NY 10002",
        customer_phone: "(212) 555-5678",
        delivery_deadline: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000).toISOString(),
        status: "assigned",
        driver_id: "DRV001",
        created_at: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        delivery_notes: "Signature required",
        package_count: 2,
        priority: "high",
      },
      {
        order_id: "ORD003",
        customer_name: "Jamie Rodriguez",
        customer_address: "789 Fashion Blvd, New York, NY 10003",
        customer_phone: "(212) 555-9012",
        delivery_deadline: new Date().toISOString(),
        status: "in-progress",
        driver_id: "DRV002",
        created_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
        delivery_notes: "Call before delivery",
        package_count: 1,
        priority: "normal",
      },
      {
        order_id: "ORD004",
        customer_name: "Taylor Williams",
        customer_address: "321 Reader St, Brooklyn, NY 11201",
        customer_phone: "(718) 555-3456",
        delivery_deadline: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
        status: "delivered",
        driver_id: "DRV001",
        created_at: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        delivery_notes: null,
        package_count: 1,
        priority: "normal",
        completed_at: new Date(Date.now() - 18 * 60 * 60 * 1000).toISOString(),
      },
      {
        order_id: "ORD005",
        customer_name: "Jordan Lee",
        customer_address: "654 Cooking Ave, Queens, NY 11101",
        customer_phone: "(718) 555-7890",
        delivery_deadline: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
        status: "delivered",
        driver_id: "DRV004",
        created_at: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString(),
        delivery_notes: "Fragile items",
        package_count: 3,
        priority: "high",
        completed_at: new Date(Date.now() - 20 * 60 * 60 * 1000).toISOString(),
      },
    ]

    setOrders(mockOrders)

    // Calculate stats
    const pending = mockOrders.filter((o) => o.status === "pending").length
    const inProgress = mockOrders.filter((o) => o.status === "in-progress").length
    const delivered = mockOrders.filter((o) => o.status === "delivered").length

    setStats({
      totalOrders: mockOrders.length,
      pendingOrders: pending,
      inProgressOrders: inProgress,
      deliveredOrders: delivered,
      activeDrivers: 4,
      totalDrivers: 5,
    })
  }, [])

  return <AdminDashboard initialOrders={orders} stats={stats} />
}
