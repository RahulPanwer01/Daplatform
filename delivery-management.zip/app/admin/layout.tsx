// Let's update the admin layout to be client-side for testing purposes

// Change the file to be client-side:
"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { AdminSidebar } from "@/components/admin/admin-sidebar"
import { SidebarProvider } from "@/components/ui/sidebar"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check if user is authenticated as admin
    const adminStr = localStorage.getItem("admin")
    const session = adminStr ? JSON.parse(adminStr) : null

    if (!session) {
      // For testing purposes, we'll be more permissive
      // Only redirect if there's definitely no admin data
      router.push("/")
    }

    setIsLoading(false)
  }, [router])

  if (isLoading) {
    return <div>Loading...</div>
  }

  return (
    <SidebarProvider>
      <div className="grid min-h-screen w-full lg:grid-cols-[280px_1fr]">
        <AdminSidebar />
        <div className="flex flex-col">{children}</div>
      </div>
    </SidebarProvider>
  )
}
