import { PackageManagement } from "@/components/admin/package-management"

export default function PackagesPage() {
  return <PackageManagement />
}
