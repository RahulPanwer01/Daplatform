import { DriverManagement } from "@/components/admin/driver-management"

export default function DriversPage() {
  return <DriverManagement />
}
