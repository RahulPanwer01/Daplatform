import { DeliveryHistory } from "@/components/admin/delivery-history"

export default function HistoryPage() {
  return <DeliveryHistory />
}
