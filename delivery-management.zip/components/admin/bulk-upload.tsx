"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import * as XLSX from "xlsx"
import { FileSpreadsheet, Upload, AlertCircle, CheckCircle, X, Download } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth/auth-provider"
import type { BulkUploadRow } from "@/lib/types"

const uploadSchema = z.object({
  file: z
    .instanceof(File, { message: "Please select a file" })
    .refine((file) => file.size > 0, "File is required")
    .refine(
      (file) =>
        [
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
          "application/vnd.ms-excel",
          "text/csv",
        ].includes(file.type),
      "Only Excel or CSV files are accepted",
    ),
})

type UploadValues = z.infer<typeof uploadSchema>

export function BulkUpload() {
  const { user } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [isOpen, setIsOpen] = useState(false)
  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)
  const [uploadError, setUploadError] = useState<string | null>(null)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [parsedData, setParsedData] = useState<BulkUploadRow[]>([])
  const [validationErrors, setValidationErrors] = useState<Record<number, string[]>>({})
  const fileInputRef = useRef<HTMLInputElement>(null)

  const form = useForm<UploadValues>({
    resolver: zodResolver(uploadSchema),
  })

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    form.setValue("file", file)
    await parseFile(file)
  }

  const parseFile = async (file: File) => {
    setUploadProgress(10)
    setUploadError(null)
    setValidationErrors({})

    try {
      const data = await readFileAsync(file)
      setUploadProgress(30)

      // Parse the data
      const workbook = XLSX.read(data, { type: "array" })
      const firstSheetName = workbook.SheetNames[0]
      const worksheet = workbook.Sheets[firstSheetName]

      // Convert to JSON
      const jsonData = XLSX.utils.sheet_to_json(worksheet)
      setUploadProgress(50)

      // Map to our expected format
      const mappedData = jsonData.map((row: any) => ({
        customer_name: row["Customer Name"] || row["customer_name"] || "",
        customer_address: row["Address"] || row["customer_address"] || "",
        customer_phone: row["Phone"] || row["customer_phone"] || "",
        delivery_deadline:
          row["Deadline"] || row["delivery_deadline"]
            ? typeof row["Deadline"] === "number"
              ? new Date(Math.round((row["Deadline"] - 25569) * 86400 * 1000)).toISOString().split("T")[0]
              : row["Deadline"] || row["delivery_deadline"]
            : "",
        delivery_notes: row["Notes"] || row["delivery_notes"] || "",
        package_count: row["Package Count"] || row["package_count"] || 1,
        priority: row["Priority"] || row["priority"] || "normal",
        package_name: row["Package Name"] || row["package_name"] || "",
        package_weight: row["Weight"] || row["package_weight"] || null,
        package_dimensions: row["Dimensions"] || row["package_dimensions"] || "",
        special_instructions: row["Special Instructions"] || row["special_instructions"] || "",
      }))

      // Validate the data
      const errors: Record<number, string[]> = {}
      mappedData.forEach((row, index) => {
        const rowErrors: string[] = []

        if (!row.customer_name) rowErrors.push("Customer name is required")
        if (!row.customer_address) rowErrors.push("Address is required")
        if (!row.customer_phone) rowErrors.push("Phone number is required")

        if (rowErrors.length > 0) {
          errors[index] = rowErrors
        }
      })

      setValidationErrors(errors)
      setParsedData(mappedData)
      setUploadProgress(100)
    } catch (error) {
      console.error("Error parsing file:", error)
      setUploadError("Failed to parse the file. Please check the format and try again.")
      setUploadProgress(0)
    }
  }

  const readFileAsync = (file: File): Promise<ArrayBuffer> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader()
      reader.onload = (e) => {
        resolve(e.target?.result as ArrayBuffer)
      }
      reader.onerror = reject
      reader.readAsArrayBuffer(file)
    })
  }

  const onSubmit = async () => {
    if (Object.keys(validationErrors).length > 0) {
      setUploadError("Please fix the validation errors before uploading")
      return
    }

    setIsUploading(true)
    setUploadProgress(0)
    setUploadError(null)

    try {
      // For demo purposes, we'll simulate the upload
      setUploadProgress(10)

      // Simulate processing time
      await new Promise((resolve) => setTimeout(resolve, 1000))
      setUploadProgress(50)

      await new Promise((resolve) => setTimeout(resolve, 1000))
      setUploadProgress(90)

      await new Promise((resolve) => setTimeout(resolve, 500))
      setUploadProgress(100)
      setUploadSuccess(true)

      toast({
        title: "Upload successful",
        description: `${parsedData.length} orders have been uploaded successfully.`,
      })

      // Reset the form after successful upload
      setTimeout(() => {
        form.reset()
        setParsedData([])
        setValidationErrors({})
        setIsUploading(false)
        setIsOpen(false)
        router.refresh()
      }, 2000)
    } catch (error) {
      console.error("Upload error:", error)
      setUploadError("Failed to upload orders. Please try again.")
      setIsUploading(false)
    }
  }

  const downloadTemplate = () => {
    const template = [
      {
        "Customer Name": "John Doe",
        Address: "123 Main St, City, State, ZIP",
        Phone: "(123) 456-7890",
        Deadline: "2023-12-31",
        Notes: "Leave at front door",
        "Package Count": 1,
        Priority: "normal",
        "Package Name": "Electronics",
        Weight: 2.5,
        Dimensions: "12x8x4",
        "Special Instructions": "Fragile",
      },
    ]

    const ws = XLSX.utils.json_to_sheet(template)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, "Orders Template")
    XLSX.writeFile(wb, "bulk_orders_template.xlsx")
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button>
          <Upload className="mr-2 h-4 w-4" />
          Bulk Upload
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Bulk Upload Orders</DialogTitle>
          <DialogDescription>Upload multiple orders at once using an Excel or CSV file.</DialogDescription>
        </DialogHeader>

        {uploadSuccess ? (
          <div className="flex flex-col items-center justify-center py-8">
            <CheckCircle className="h-16 w-16 text-green-500 mb-4" />
            <h3 className="text-xl font-semibold mb-2">Upload Successful!</h3>
            <p className="text-center text-muted-foreground mb-6">
              Your orders have been successfully uploaded and are now available in the system.
            </p>
            <Button
              onClick={() => {
                setUploadSuccess(false)
                setIsOpen(false)
                router.refresh()
              }}
            >
              Close
            </Button>
          </div>
        ) : (
          <>
            <Tabs defaultValue="upload" className="w-full">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="upload">Upload File</TabsTrigger>
                <TabsTrigger value="preview" disabled={parsedData.length === 0}>
                  Preview Data
                </TabsTrigger>
              </TabsList>

              <TabsContent value="upload" className="space-y-4 py-4">
                <div className="flex justify-end">
                  <Button variant="outline" size="sm" onClick={downloadTemplate}>
                    <Download className="mr-2 h-4 w-4" />
                    Download Template
                  </Button>
                </div>

                <Form {...form}>
                  <form className="space-y-4">
                    <FormField
                      control={form.control}
                      name="file"
                      render={({ field: { onChange, value, ...rest } }) => (
                        <FormItem>
                          <FormLabel>Upload File</FormLabel>
                          <FormControl>
                            <div className="grid w-full gap-2">
                              <Input
                                id="file"
                                type="file"
                                accept=".xlsx,.xls,.csv"
                                ref={fileInputRef}
                                onChange={handleFileChange}
                                className="hidden"
                                {...rest}
                              />
                              <div
                                className="border-2 border-dashed rounded-md p-8 text-center cursor-pointer hover:border-primary/50 transition-colors"
                                onClick={() => fileInputRef.current?.click()}
                              >
                                {form.getValues("file") ? (
                                  <div className="flex flex-col items-center">
                                    <FileSpreadsheet className="h-10 w-10 text-primary mb-2" />
                                    <p className="font-medium">{form.getValues("file").name}</p>
                                    <p className="text-sm text-muted-foreground">
                                      {(form.getValues("file").size / 1024).toFixed(2)} KB
                                    </p>
                                    <Button
                                      variant="ghost"
                                      size="sm"
                                      className="mt-2"
                                      onClick={(e) => {
                                        e.stopPropagation()
                                        form.reset()
                                        setParsedData([])
                                        setValidationErrors({})
                                        if (fileInputRef.current) {
                                          fileInputRef.current.value = ""
                                        }
                                      }}
                                    >
                                      <X className="h-4 w-4 mr-1" />
                                      Remove
                                    </Button>
                                  </div>
                                ) : (
                                  <div className="flex flex-col items-center">
                                    <FileSpreadsheet className="h-10 w-10 text-muted-foreground mb-2" />
                                    <p className="font-medium">Click to select a file</p>
                                    <p className="text-sm text-muted-foreground">or drag and drop here</p>
                                    <p className="text-xs text-muted-foreground mt-2">
                                      Supports Excel (.xlsx, .xls) and CSV files
                                    </p>
                                  </div>
                                )}
                              </div>
                            </div>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </form>
                </Form>

                {uploadProgress > 0 && uploadProgress < 100 && (
                  <div className="space-y-2">
                    <Progress value={uploadProgress} className="h-2" />
                    <p className="text-sm text-muted-foreground text-center">
                      {isUploading ? "Uploading orders..." : "Processing file..."}
                    </p>
                  </div>
                )}

                {uploadError && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Error</AlertTitle>
                    <AlertDescription>{uploadError}</AlertDescription>
                  </Alert>
                )}

                {parsedData.length > 0 && (
                  <div className="space-y-2">
                    <p className="text-sm">
                      <span className="font-medium">{parsedData.length}</span> orders found in file.
                      {Object.keys(validationErrors).length > 0 && (
                        <span className="text-destructive ml-1">
                          {Object.keys(validationErrors).length} orders have validation errors.
                        </span>
                      )}
                    </p>
                  </div>
                )}
              </TabsContent>

              <TabsContent value="preview">
                <div className="border rounded-md overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead className="w-12">#</TableHead>
                        <TableHead>Customer</TableHead>
                        <TableHead>Address</TableHead>
                        <TableHead>Phone</TableHead>
                        <TableHead>Deadline</TableHead>
                        <TableHead>Package</TableHead>
                        <TableHead className="text-right">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {parsedData.map((row, index) => (
                        <TableRow key={index} className={validationErrors[index] ? "bg-red-50" : ""}>
                          <TableCell>{index + 1}</TableCell>
                          <TableCell>
                            {row.customer_name || <span className="text-destructive">Missing</span>}
                          </TableCell>
                          <TableCell>
                            {row.customer_address || <span className="text-destructive">Missing</span>}
                          </TableCell>
                          <TableCell>
                            {row.customer_phone || <span className="text-destructive">Missing</span>}
                          </TableCell>
                          <TableCell>{row.delivery_deadline || "N/A"}</TableCell>
                          <TableCell>
                            {row.package_name ? (
                              <div className="text-sm">
                                <div>{row.package_name}</div>
                                {row.package_weight && (
                                  <div className="text-muted-foreground">{row.package_weight} kg</div>
                                )}
                              </div>
                            ) : (
                              "Default Package"
                            )}
                          </TableCell>
                          <TableCell className="text-right">
                            {validationErrors[index] ? (
                              <Badge variant="destructive">Error</Badge>
                            ) : (
                              <Badge variant="outline">Valid</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                {Object.keys(validationErrors).length > 0 && (
                  <Alert variant="destructive" className="mt-4">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Validation Errors</AlertTitle>
                    <AlertDescription>
                      <p className="mb-2">Please fix the following errors before uploading:</p>
                      <ul className="list-disc pl-5 space-y-1">
                        {Object.entries(validationErrors).map(([rowIndex, errors]) => (
                          <li key={rowIndex}>
                            Row {Number.parseInt(rowIndex) + 1}: {errors.join(", ")}
                          </li>
                        ))}
                      </ul>
                    </AlertDescription>
                  </Alert>
                )}
              </TabsContent>
            </Tabs>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsOpen(false)}>
                Cancel
              </Button>
              <Button
                onClick={onSubmit}
                disabled={isUploading || parsedData.length === 0 || Object.keys(validationErrors).length > 0}
              >
                {isUploading ? <>Uploading...</> : <>Upload {parsedData.length} Orders</>}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
