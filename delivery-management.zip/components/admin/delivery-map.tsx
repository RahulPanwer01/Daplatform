"use client"

import { useState } from "react"
import { MapPin, Package, Truck, User } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { mockDeliveries, mockDrivers } from "@/lib/mock-data"

export function DeliveryMap() {
  const [selectedDriver, setSelectedDriver] = useState<string | null>(null)
  const [selectedDelivery, setSelectedDelivery] = useState<string | null>(null)

  return (
    <div className="flex flex-col h-full">
      <header className="border-b">
        <div className="flex h-16 items-center px-4 gap-4">
          <SidebarTrigger className="lg:hidden" />
          <h1 className="text-xl font-semibold">Live Map</h1>
        </div>
      </header>
      <main className="flex-1 overflow-hidden p-4 md:p-6">
        <div className="grid grid-cols-1 lg:grid-cols-[1fr_300px] gap-4 h-full">
          <Card className="flex flex-col">
            <CardHeader className="pb-2">
              <CardTitle>Delivery Map</CardTitle>
              <CardDescription>Real-time view of all drivers and deliveries</CardDescription>
            </CardHeader>
            <CardContent className="flex-1 p-0 relative">
              <div className="absolute inset-0 bg-muted/20 flex items-center justify-center">
                <div className="text-center p-6 max-w-md">
                  <MapPin className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-lg font-medium mb-2">Interactive Map</h3>
                  <p className="text-sm text-muted-foreground mb-4">
                    This is where the interactive map would be displayed, showing real-time locations of drivers and
                    delivery destinations.
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {mockDrivers.map((driver) => (
                      <Badge
                        key={driver.id}
                        variant={driver.status === "active" ? "default" : "outline"}
                        className="cursor-pointer"
                        onClick={() => setSelectedDriver(driver.id)}
                      >
                        <Truck className="mr-1 h-3 w-3" />
                        {driver.name}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="flex flex-col gap-4">
            <Tabs defaultValue="drivers">
              <TabsList className="grid grid-cols-2">
                <TabsTrigger value="drivers">Drivers</TabsTrigger>
                <TabsTrigger value="deliveries">Deliveries</TabsTrigger>
              </TabsList>
              <TabsContent value="drivers" className="mt-2 space-y-4">
                {mockDrivers.map((driver) => (
                  <Card
                    key={driver.id}
                    className={`cursor-pointer transition-all ${selectedDriver === driver.id ? "ring-2 ring-primary" : ""}`}
                    onClick={() => setSelectedDriver(driver.id)}
                  >
                    <CardHeader className="p-4 pb-2">
                      <div className="flex justify-between items-start">
                        <div className="flex items-center gap-2">
                          <Truck className="h-4 w-4" />
                          <CardTitle className="text-base">{driver.name}</CardTitle>
                        </div>
                        <Badge variant={driver.status === "active" ? "success" : "outline"}>
                          {driver.status === "active" ? "Active" : "Inactive"}
                        </Badge>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4 pt-0">
                      <div className="text-sm">
                        <div className="flex items-center gap-2 mb-1">
                          <MapPin className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">{driver.currentLocation || "Unknown location"}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Package className="h-3 w-3 text-muted-foreground" />
                          <span className="text-muted-foreground">{driver.activeDeliveries} active deliveries</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
              <TabsContent value="deliveries" className="mt-2 space-y-4">
                {mockDeliveries
                  .filter((d) => d.status !== "delivered")
                  .map((delivery) => (
                    <Card
                      key={delivery.id}
                      className={`cursor-pointer transition-all ${selectedDelivery === delivery.id ? "ring-2 ring-primary" : ""}`}
                      onClick={() => setSelectedDelivery(delivery.id)}
                    >
                      <CardHeader className="p-4 pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle className="text-base">{delivery.packageInfo.name}</CardTitle>
                          <Badge
                            variant={
                              delivery.status === "in-progress"
                                ? "secondary"
                                : delivery.status === "delivered"
                                  ? "success"
                                  : delivery.status === "issue"
                                    ? "destructive"
                                    : "outline"
                            }
                          >
                            {delivery.status}
                          </Badge>
                        </div>
                      </CardHeader>
                      <CardContent className="p-4 pt-0">
                        <div className="text-sm">
                          <div className="flex items-center gap-2 mb-1">
                            <User className="h-3 w-3 text-muted-foreground" />
                            <span className="text-muted-foreground">{delivery.recipient.name}</span>
                          </div>
                          <div className="flex items-center gap-2 mb-1">
                            <MapPin className="h-3 w-3 text-muted-foreground" />
                            <span className="text-muted-foreground truncate">{delivery.recipient.address}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Truck className="h-3 w-3 text-muted-foreground" />
                            <span className="text-muted-foreground">{delivery.driverName}</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
              </TabsContent>
            </Tabs>

            <Card>
              <CardHeader className="p-4 pb-2">
                <CardTitle className="text-base">Map Controls</CardTitle>
              </CardHeader>
              <CardContent className="p-4 pt-0 space-y-2">
                <Button variant="outline" className="w-full justify-start">
                  <MapPin className="mr-2 h-4 w-4" />
                  Center Map
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Package className="mr-2 h-4 w-4" />
                  Show All Deliveries
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Truck className="mr-2 h-4 w-4" />
                  Show All Drivers
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
