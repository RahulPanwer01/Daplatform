"use client"
import { useState } from "react"
import { MoreHorizontal, Edit, Trash2, CheckCircle2, AlertCircle, Clock, Truck, Eye } from "lucide-react"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth/auth-provider"
import { formatDistanceToNow } from "@/lib/utils"
import type { Order } from "@/lib/types"

interface DeliveryTableProps {
  orders: Order[]
  setOrders: (orders: Order[]) => void
}

export function DeliveryTable({ orders, setOrders }: DeliveryTableProps) {
  const { user } = useAuth()
  const { toast } = useToast()
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null)
  const [isViewingPOD, setIsViewingPOD] = useState(false)
  const [podData, setPodData] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return <Badge variant="outline">Pending</Badge>
      case "assigned":
        return <Badge variant="outline">Assigned</Badge>
      case "in-progress":
        return <Badge variant="secondary">In Progress</Badge>
      case "delivered":
        return <Badge variant="success">Delivered</Badge>
      case "issue":
        return <Badge variant="destructive">Issue</Badge>
      case "cancelled":
        return <Badge variant="destructive">Cancelled</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const handleStatusChange = async (orderId: string, newStatus: string) => {
    if (!user) return

    try {
      // For demo purposes, we'll update the local state directly
      const updatedOrders = orders.map((order) =>
        order.order_id === orderId
          ? {
              ...order,
              status: newStatus,
              ...(newStatus === "delivered" ? { completed_at: new Date().toISOString() } : {}),
            }
          : order,
      )

      setOrders(updatedOrders)

      toast({
        title: "Status updated",
        description: `Order #${orderId.slice(0, 8)} has been marked as ${newStatus}`,
      })
    } catch (error) {
      console.error("Error updating status:", error)
      toast({
        title: "Error",
        description: "Failed to update order status",
        variant: "destructive",
      })
    }
  }

  const handleDeleteOrder = async (orderId: string) => {
    try {
      // For demo purposes, we'll update the local state directly
      setOrders(orders.filter((order) => order.order_id !== orderId))

      toast({
        title: "Order deleted",
        description: `Order #${orderId.slice(0, 8)} has been deleted`,
      })
    } catch (error) {
      console.error("Error deleting order:", error)
      toast({
        title: "Error",
        description: "Failed to delete order",
        variant: "destructive",
      })
    }
  }

  const viewProofOfDelivery = async (orderId: string) => {
    setIsLoading(true)
    try {
      // For demo purposes, we'll create mock POD data
      const mockPodData = {
        photo_url: "/delivery-confirmation.png",
        signature_url: "/digital-signature.png",
        notes: "Delivered to front desk. Recipient confirmed delivery.",
        created_at: new Date().toISOString(),
        created_by: "DRV001",
        location: {
          lat: 40.7128,
          lng: -74.006,
          address: "New York, NY, USA",
        },
      }

      setPodData(mockPodData)
      setIsViewingPOD(true)
    } catch (error) {
      console.error("Error fetching proof of delivery:", error)
      toast({
        title: "Error",
        description: "Failed to fetch proof of delivery",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>Customer</TableHead>
              <TableHead>Address</TableHead>
              <TableHead>Driver</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Updated</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {orders.length === 0 ? (
              <TableRow>
                <TableCell colSpan={7} className="h-24 text-center">
                  No orders found
                </TableCell>
              </TableRow>
            ) : (
              orders.map((order) => (
                <TableRow key={order.order_id}>
                  <TableCell className="font-medium">{order.order_id.slice(0, 8)}</TableCell>
                  <TableCell>{order.customer_name}</TableCell>
                  <TableCell>
                    <div className="text-sm text-muted-foreground truncate max-w-[150px]">{order.customer_address}</div>
                  </TableCell>
                  <TableCell>{order.driver_id ? "Assigned" : "Unassigned"}</TableCell>
                  <TableCell>{getStatusBadge(order.status)}</TableCell>
                  <TableCell>{formatDistanceToNow(order.created_at)}</TableCell>
                  <TableCell className="text-right">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuLabel>Actions</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => setSelectedOrder(order)}>
                          <Edit className="mr-2 h-4 w-4" />
                          <span>Edit Details</span>
                        </DropdownMenuItem>
                        {order.status === "delivered" && (
                          <DropdownMenuItem onClick={() => viewProofOfDelivery(order.order_id)}>
                            <Eye className="mr-2 h-4 w-4" />
                            <span>View Proof of Delivery</span>
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuSeparator />
                        <DropdownMenuItem onClick={() => handleStatusChange(order.order_id, "pending")}>
                          <Clock className="mr-2 h-4 w-4" />
                          <span>Mark as Pending</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusChange(order.order_id, "assigned")}>
                          <Truck className="mr-2 h-4 w-4" />
                          <span>Mark as Assigned</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusChange(order.order_id, "in-progress")}>
                          <Truck className="mr-2 h-4 w-4" />
                          <span>Mark as In Progress</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusChange(order.order_id, "delivered")}>
                          <CheckCircle2 className="mr-2 h-4 w-4" />
                          <span>Mark as Delivered</span>
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleStatusChange(order.order_id, "issue")}>
                          <AlertCircle className="mr-2 h-4 w-4" />
                          <span>Report Issue</span>
                        </DropdownMenuItem>
                        <DropdownMenuSeparator />
                        <DropdownMenuItem
                          onClick={() => handleDeleteOrder(order.order_id)}
                          className="text-destructive focus:text-destructive"
                        >
                          <Trash2 className="mr-2 h-4 w-4" />
                          <span>Delete Order</span>
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Edit Order Dialog */}
      {selectedOrder && (
        <Dialog open={!!selectedOrder} onOpenChange={(open) => !open && setSelectedOrder(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Order</DialogTitle>
              <DialogDescription>Update the details for order #{selectedOrder.order_id.slice(0, 8)}</DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="customer-name" className="text-right">
                  Customer
                </Label>
                <Input id="customer-name" defaultValue={selectedOrder.customer_name} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="customer-address" className="text-right">
                  Address
                </Label>
                <Textarea id="customer-address" defaultValue={selectedOrder.customer_address} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="customer-phone" className="text-right">
                  Phone
                </Label>
                <Input id="customer-phone" defaultValue={selectedOrder.customer_phone} className="col-span-3" />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="delivery-notes" className="text-right">
                  Notes
                </Label>
                <Textarea
                  id="delivery-notes"
                  defaultValue={selectedOrder.delivery_notes || ""}
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setSelectedOrder(null)}>
                Cancel
              </Button>
              <Button
                onClick={() => {
                  toast({
                    title: "Changes saved",
                    description: "Order details have been updated successfully.",
                  })
                  setSelectedOrder(null)
                }}
              >
                Save Changes
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Proof of Delivery Dialog */}
      {isViewingPOD && (
        <Dialog open={isViewingPOD} onOpenChange={setIsViewingPOD}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Proof of Delivery</DialogTitle>
              <DialogDescription>Delivery confirmation details</DialogDescription>
            </DialogHeader>
            {isLoading ? (
              <div className="py-8 text-center">Loading proof of delivery...</div>
            ) : podData ? (
              <div className="space-y-4">
                {podData.photo_url && (
                  <div>
                    <Label className="block mb-2">Photo</Label>
                    <img
                      src={podData.photo_url || "/placeholder.svg"}
                      alt="Proof of delivery"
                      className="w-full h-auto max-h-[300px] object-contain border rounded-md"
                    />
                  </div>
                )}
                {podData.signature_url && (
                  <div>
                    <Label className="block mb-2">Signature</Label>
                    <img
                      src={podData.signature_url || "/placeholder.svg"}
                      alt="Signature"
                      className="w-full h-auto max-h-[200px] object-contain bg-white border rounded-md p-2"
                    />
                  </div>
                )}
                {podData.notes && (
                  <div>
                    <Label className="block mb-2">Notes</Label>
                    <div className="p-3 bg-muted rounded-md">{podData.notes}</div>
                  </div>
                )}
                <div>
                  <Label className="block mb-2">Delivery Information</Label>
                  <div className="text-sm space-y-1">
                    <p>
                      <span className="font-medium">Completed by:</span> Driver ID {podData.created_by}
                    </p>
                    <p>
                      <span className="font-medium">Date:</span> {new Date(podData.created_at).toLocaleString()}
                    </p>
                    {podData.location && (
                      <p>
                        <span className="font-medium">Location:</span>{" "}
                        {podData.location.address || `${podData.location.lat}, ${podData.location.lng}`}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground">No proof of delivery found for this order.</div>
            )}
            <DialogFooter>
              <Button onClick={() => setIsViewingPOD(false)}>Close</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </>
  )
}
