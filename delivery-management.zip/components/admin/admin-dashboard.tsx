"use client"

import { useState, useEffect } from "react"
import { CheckCircle2, Clock, Package, Users, Truck } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Progress } from "@/components/ui/progress"
import { DeliveryTable } from "@/components/admin/delivery-table"
import { BulkUpload } from "@/components/admin/bulk-upload"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { hasSupabaseConnection } from "@/lib/supabase/client"
import type { Order } from "@/lib/types"

interface AdminDashboardProps {
  initialOrders: Order[]
  stats: {
    totalOrders: number
    pendingOrders: number
    inProgressOrders: number
    deliveredOrders: number
    activeDrivers: number
    totalDrivers: number
  }
}

export function AdminDashboard({ initialOrders, stats: initialStats }: AdminDashboardProps) {
  const [orders, setOrders] = useState<Order[]>(initialOrders)
  const [stats, setStats] = useState(initialStats)

  // For demo purposes, we won't use real-time subscriptions if Supabase isn't connected
  useEffect(() => {
    if (!hasSupabaseConnection()) {
      console.log("Using mock data - Supabase connection not available")
    }
  }, [])

  return (
    <div className="flex flex-col h-full">
      <header className="border-b">
        <div className="flex h-16 items-center px-4 gap-4">
          <SidebarTrigger className="lg:hidden" />
          <h1 className="text-xl font-semibold">Dashboard</h1>
        </div>
      </header>
      <main className="flex-1 overflow-auto p-4 md:p-6">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Orders</CardTitle>
              <Package className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalOrders}</div>
              <p className="text-xs text-muted-foreground">All time orders</p>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Progress</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.inProgressOrders}</div>
              <Progress value={(stats.inProgressOrders / (stats.totalOrders || 1)) * 100} className="h-2 mt-2" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Completed</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.deliveredOrders}</div>
              <Progress value={(stats.deliveredOrders / (stats.totalOrders || 1)) * 100} className="h-2 mt-2" />
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Drivers</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.activeDrivers}</div>
              <p className="text-xs text-muted-foreground">
                {stats.activeDrivers} of {stats.totalDrivers} drivers currently on duty
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-6">
          <Tabs defaultValue="active" className="w-full">
            <div className="flex items-center justify-between">
              <TabsList>
                <TabsTrigger value="active">Active Orders</TabsTrigger>
                <TabsTrigger value="all">All Orders</TabsTrigger>
              </TabsList>
              <div className="flex gap-2">
                <BulkUpload />
                <Button>
                  <Truck className="mr-2 h-4 w-4" />
                  Assign New Order
                </Button>
              </div>
            </div>
            <TabsContent value="active" className="mt-4">
              <DeliveryTable
                orders={orders.filter((o) => o.status !== "delivered" && o.status !== "cancelled")}
                setOrders={setOrders}
              />
            </TabsContent>
            <TabsContent value="all" className="mt-4">
              <DeliveryTable orders={orders} setOrders={setOrders} />
            </TabsContent>
          </Tabs>
        </div>
      </main>
    </div>
  )
}
