"use client"

import { useState, useEffect } from "react"
import { CheckCircle2, Clock, MapPin, Package, AlertTriangle, ChevronRight, Phone, MessageSquare } from "lucide-react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Skeleton } from "@/components/ui/skeleton"
import { ProofOfDelivery } from "@/components/driver/proof-of-delivery"
import { supabase } from "@/lib/supabase/client"
import { useAuth } from "@/components/auth/auth-provider"
import { formatDistanceToNow, getInitials } from "@/lib/utils"
import type { Order } from "@/lib/types"

interface DriverDashboardProps {
  orders: Order[]
  isLoading: boolean
}

export function DriverDashboard({ orders, isLoading }: DriverDashboardProps) {
  const { user } = useAuth()
  const [stats, setStats] = useState({
    assigned: 0,
    inProgress: 0,
    completed: 0,
    issues: 0,
  })

  useEffect(() => {
    // Calculate stats based on orders
    const assigned = orders.filter((o) => o.status === "assigned").length
    const inProgress = orders.filter((o) => o.status === "in-progress").length
    const completed = orders.filter((o) => o.status === "delivered").length
    const issues = orders.filter((o) => o.status === "issue").length

    setStats({
      assigned,
      inProgress,
      completed,
      issues,
    })
  }, [orders])

  const updateOrderStatus = async (orderId: string, newStatus: string) => {
    if (!user) return

    try {
      const order = orders.find((o) => o.order_id === orderId)
      if (!order) return

      // Update order status
      const { error } = await supabase
        .from("orders")
        .update({
          status: newStatus,
          ...(newStatus === "delivered" ? { completed_at: new Date().toISOString() } : {}),
        })
        .eq("order_id", orderId)

      if (error) throw error

      // Add to delivery history
      await supabase.from("delivery_history").insert({
        order_id: orderId,
        previous_status: order.status,
        new_status: newStatus,
        changed_by: user.id,
        notes: `Status updated by driver`,
      })
    } catch (error) {
      console.error("Error updating order status:", error)
    }
  }

  if (isLoading) {
    return <DriverDashboardSkeleton />
  }

  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold mb-2">Welcome, {user?.name || "Driver"}</h1>
        <p className="text-muted-foreground">Here are your deliveries for today</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Assigned</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.assigned}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">In Progress</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.inProgress}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Completed Today</CardTitle>
            <CheckCircle2 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.completed}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Issues</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.issues}</div>
          </CardContent>
        </Card>
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle>Today's Progress</CardTitle>
          <CardDescription>
            You've completed {stats.completed} out of {orders.length || 1} deliveries
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Progress value={orders.length ? (stats.completed / orders.length) * 100 : 0} className="h-2" />
        </CardContent>
      </Card>

      <Tabs defaultValue="active">
        <TabsList className="grid w-full grid-cols-3 mb-4">
          <TabsTrigger value="active">Active Deliveries</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
          <TabsTrigger value="all">All</TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          <div className="space-y-4">
            {orders.filter((o) => o.status !== "delivered").length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <Package className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No active deliveries</p>
                  <p className="text-sm text-muted-foreground">All your deliveries are completed</p>
                </CardContent>
              </Card>
            ) : (
              orders
                .filter((o) => o.status !== "delivered")
                .map((order) => <DeliveryCard key={order.order_id} order={order} updateStatus={updateOrderStatus} />)
            )}
          </div>
        </TabsContent>

        <TabsContent value="completed">
          <div className="space-y-4">
            {orders.filter((o) => o.status === "delivered").length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <CheckCircle2 className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No completed deliveries</p>
                  <p className="text-sm text-muted-foreground">You haven't completed any deliveries yet</p>
                </CardContent>
              </Card>
            ) : (
              orders
                .filter((o) => o.status === "delivered")
                .map((order) => (
                  <DeliveryCard key={order.order_id} order={order} updateStatus={updateOrderStatus} isCompleted />
                ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="all">
          <div className="space-y-4">
            {orders.length === 0 ? (
              <Card>
                <CardContent className="flex flex-col items-center justify-center p-6">
                  <Package className="h-12 w-12 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium">No deliveries assigned</p>
                  <p className="text-sm text-muted-foreground">You don't have any deliveries assigned yet</p>
                </CardContent>
              </Card>
            ) : (
              orders.map((order) => (
                <DeliveryCard
                  key={order.order_id}
                  order={order}
                  updateStatus={updateOrderStatus}
                  isCompleted={order.status === "delivered"}
                />
              ))
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}

interface DeliveryCardProps {
  order: Order
  updateStatus: (id: string, status: string) => void
  isCompleted?: boolean
}

function DeliveryCard({ order, updateStatus, isCompleted = false }: DeliveryCardProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case "assigned":
        return <Badge variant="outline">Assigned</Badge>
      case "in-progress":
        return <Badge variant="secondary">In Progress</Badge>
      case "delivered":
        return <Badge variant="success">Delivered</Badge>
      case "issue":
        return <Badge variant="destructive">Issue</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>Order #{order.order_id.slice(0, 8)}</CardTitle>
            <CardDescription>Due: {new Date(order.delivery_deadline).toLocaleDateString()}</CardDescription>
          </div>
          {getStatusBadge(order.status)}
        </div>
      </CardHeader>
      <CardContent className="pb-2">
        <div className="space-y-4">
          <div className="flex items-start gap-3">
            <Avatar className="h-9 w-9 mt-1">
              <AvatarImage
                src={`/abstract-geometric-shapes.png?key=bc5wq&height=36&width=36&query=${order.customer_name}`}
                alt={order.customer_name}
              />
              <AvatarFallback>{getInitials(order.customer_name)}</AvatarFallback>
            </Avatar>
            <div>
              <p className="font-medium">{order.customer_name}</p>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <MapPin className="h-3.5 w-3.5" />
                <span>{order.customer_address}</span>
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground mt-1">
                <Phone className="h-3.5 w-3.5" />
                <span>{order.customer_phone}</span>
              </div>
            </div>
          </div>

          {order.delivery_notes && (
            <div className="bg-muted/50 p-3 rounded-md text-sm">
              <p className="font-medium mb-1">Delivery Notes:</p>
              <p className="text-muted-foreground">{order.delivery_notes}</p>
            </div>
          )}

          <div className="flex items-center justify-between text-sm">
            <div className="text-muted-foreground">
              {order.status === "delivered"
                ? `Delivered ${formatDistanceToNow(order.completed_at || order.created_at)}`
                : `Updated ${formatDistanceToNow(order.created_at)}`}
            </div>
            {!isCompleted && (
              <Button variant="link" size="sm" className="p-0 h-auto">
                View on Map <ChevronRight className="h-3 w-3 ml-1" />
              </Button>
            )}
          </div>
        </div>
      </CardContent>
      {!isCompleted && (
        <CardFooter className="flex gap-2 pt-2">
          {order.status === "assigned" && (
            <Button className="flex-1" onClick={() => updateStatus(order.order_id, "in-progress")}>
              Start Delivery
            </Button>
          )}
          {order.status === "in-progress" && (
            <>
              <Button variant="outline" className="flex-1" onClick={() => updateStatus(order.order_id, "issue")}>
                <AlertTriangle className="mr-2 h-4 w-4" />
                Report Issue
              </Button>
              <ProofOfDelivery order={order} onComplete={() => updateStatus(order.order_id, "delivered")} />
            </>
          )}
          {order.status === "issue" && (
            <Button variant="outline" className="flex-1">
              <MessageSquare className="mr-2 h-4 w-4" />
              Contact Support
            </Button>
          )}
        </CardFooter>
      )}
    </Card>
  )
}

function DriverDashboardSkeleton() {
  return (
    <div className="container mx-auto p-4 md:p-6">
      <div className="mb-6">
        <Skeleton className="h-8 w-48 mb-2" />
        <Skeleton className="h-4 w-64" />
      </div>

      <div className="grid gap-4 md:grid-cols-4 mb-6">
        {Array(4)
          .fill(0)
          .map((_, i) => (
            <Card key={i}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <Skeleton className="h-4 w-24" />
                <Skeleton className="h-4 w-4" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-8" />
              </CardContent>
            </Card>
          ))}
      </div>

      <Card className="mb-6">
        <CardHeader>
          <Skeleton className="h-6 w-32 mb-2" />
          <Skeleton className="h-4 w-48" />
        </CardHeader>
        <CardContent>
          <Skeleton className="h-2 w-full" />
        </CardContent>
      </Card>

      <div className="mb-4">
        <Skeleton className="h-10 w-full" />
      </div>

      <div className="space-y-4">
        {Array(3)
          .fill(0)
          .map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <div className="flex justify-between">
                  <div>
                    <Skeleton className="h-5 w-32 mb-2" />
                    <Skeleton className="h-4 w-24" />
                  </div>
                  <Skeleton className="h-6 w-20" />
                </div>
              </CardHeader>
              <CardContent className="pb-2">
                <div className="flex items-start gap-3">
                  <Skeleton className="h-9 w-9 rounded-full" />
                  <div className="space-y-2 flex-1">
                    <Skeleton className="h-4 w-32" />
                    <Skeleton className="h-3 w-full" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                </div>
              </CardContent>
              <CardFooter className="pt-2">
                <Skeleton className="h-9 w-full" />
              </CardFooter>
            </Card>
          ))}
      </div>
    </div>
  )
}
