"use client"

import type React from "react"

import { useState, useRef } from "react"
import { useRouter } from "next/navigation"
import { Camera, X, Check, FilePenLineIcon as Signature } from "lucide-react"
import SignatureCanvas from "react-signature-canvas"

import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { useToast } from "@/components/ui/use-toast"
import { useAuth } from "@/components/auth/auth-provider"
import type { Order } from "@/lib/types"

interface ProofOfDeliveryProps {
  order: Order
  onComplete: () => void
}

export function ProofOfDelivery({ order, onComplete }: ProofOfDeliveryProps) {
  const { user } = useAuth()
  const router = useRouter()
  const { toast } = useToast()
  const [isOpen, setIsOpen] = useState(false)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [activeTab, setActiveTab] = useState("photo")
  const [photo, setPhoto] = useState<File | null>(null)
  const [photoPreview, setPhotoPreview] = useState<string | null>(null)
  const [notes, setNotes] = useState("")
  const fileInputRef = useRef<HTMLInputElement>(null)
  const signatureRef = useRef<SignatureCanvas>(null)
  const [signatureDataURL, setSignatureDataURL] = useState<string | null>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setPhoto(file)
    const reader = new FileReader()
    reader.onloadend = () => {
      setPhotoPreview(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const clearSignature = () => {
    if (signatureRef.current) {
      signatureRef.current.clear()
      setSignatureDataURL(null)
    }
  }

  const saveSignature = () => {
    if (signatureRef.current && !signatureRef.current.isEmpty()) {
      const dataURL = signatureRef.current.toDataURL("image/png")
      setSignatureDataURL(dataURL)
    }
  }

  const handleSubmit = async () => {
    if (!user) return

    // Require either a photo or signature
    if (!photo && !signatureDataURL) {
      toast({
        title: "Missing proof of delivery",
        description: "Please provide either a photo or signature as proof of delivery.",
        variant: "destructive",
      })
      return
    }

    setIsSubmitting(true)

    try {
      // For demo purposes, we'll simulate the submission
      await new Promise((resolve) => setTimeout(resolve, 1500))

      toast({
        title: "Delivery completed",
        description: "Proof of delivery has been recorded successfully.",
      })

      setIsOpen(false)
      onComplete()
      router.refresh()
    } catch (error) {
      console.error("Error submitting proof of delivery:", error)
      toast({
        title: "Error",
        description: "Failed to submit proof of delivery. Please try again.",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button>
          <Check className="mr-2 h-4 w-4" />
          Complete Delivery
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Proof of Delivery</DialogTitle>
          <DialogDescription>Provide proof of delivery for order #{order.order_id.slice(0, 8)}</DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="photo">
              <Camera className="h-4 w-4 mr-2" />
              Photo
            </TabsTrigger>
            <TabsTrigger value="signature">
              <Signature className="h-4 w-4 mr-2" />
              Signature
            </TabsTrigger>
          </TabsList>

          <TabsContent value="photo" className="space-y-4 py-4">
            <div className="grid w-full gap-2">
              <input
                id="photo"
                type="file"
                accept="image/*"
                capture="environment"
                ref={fileInputRef}
                onChange={handleFileChange}
                className="hidden"
              />
              {photoPreview ? (
                <div className="relative">
                  <img
                    src={photoPreview || "/placeholder.svg"}
                    alt="Delivery proof"
                    className="w-full h-48 object-cover rounded-md"
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2 h-8 w-8 rounded-full"
                    onClick={() => {
                      setPhoto(null)
                      setPhotoPreview(null)
                      if (fileInputRef.current) {
                        fileInputRef.current.value = ""
                      }
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <Button
                  variant="outline"
                  className="h-48 flex flex-col items-center justify-center border-dashed"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <Camera className="h-8 w-8 mb-2 text-muted-foreground" />
                  <span>Take a photo</span>
                  <span className="text-xs text-muted-foreground mt-1">or select from gallery</span>
                </Button>
              )}
            </div>
          </TabsContent>

          <TabsContent value="signature" className="space-y-4 py-4">
            <div className="border rounded-md p-2 bg-background">
              {signatureDataURL ? (
                <div className="relative">
                  <img
                    src={signatureDataURL || "/placeholder.svg"}
                    alt="Signature"
                    className="w-full h-48 object-contain bg-white rounded-md"
                  />
                  <Button
                    variant="destructive"
                    size="icon"
                    className="absolute top-2 right-2 h-8 w-8 rounded-full"
                    onClick={() => {
                      setSignatureDataURL(null)
                      clearSignature()
                    }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              ) : (
                <div className="relative">
                  <div className="bg-white rounded-md">
                    <SignatureCanvas
                      ref={signatureRef}
                      canvasProps={{
                        width: 500,
                        height: 200,
                        className: "w-full h-48 rounded-md",
                      }}
                      backgroundColor="white"
                    />
                  </div>
                  <div className="absolute bottom-2 right-2 flex gap-2">
                    <Button variant="outline" size="sm" onClick={clearSignature}>
                      Clear
                    </Button>
                    <Button size="sm" onClick={saveSignature}>
                      Save
                    </Button>
                  </div>
                </div>
              )}
            </div>
          </TabsContent>
        </Tabs>

        <div className="space-y-2">
          <label htmlFor="notes" className="text-sm font-medium">
            Delivery Notes (Optional)
          </label>
          <Textarea
            id="notes"
            placeholder="Add any notes about the delivery..."
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setIsOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleSubmit} disabled={isSubmitting}>
            {isSubmitting ? "Submitting..." : "Complete Delivery"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
