"use client"

import type React from "react"

import { createContext, useContext, useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { supabase, hasSupabaseConnection } from "@/lib/supabase/client"
import type { User, Role } from "@/lib/types"

interface AuthContextType {
  user: User | null
  role: Role | null
  isLoading: boolean
  signOut: () => Promise<void>
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  role: null,
  isLoading: true,
  signOut: async () => {},
})

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [role, setRole] = useState<Role | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const checkUser = async () => {
      setIsLoading(true)

      try {
        // Check for admin in localStorage (for demo purposes)
        const adminStr = localStorage.getItem("admin")

        if (adminStr) {
          const admin = JSON.parse(adminStr)
          setUser({
            id: admin.id,
            email: admin.email,
            role: "admin",
            name: admin.name,
          })
          setRole("admin")
        } else {
          // Check for driver in localStorage
          const driverStr = localStorage.getItem("driver")

          if (driverStr) {
            const driver = JSON.parse(driverStr)
            setUser({
              id: driver.driver_id,
              email: driver.email,
              role: "driver",
              name: driver.name,
            })
            setRole("driver")
          } else {
            // Only check Supabase if we have a connection
            if (hasSupabaseConnection()) {
              // Check for admin user in Supabase Auth
              const {
                data: { session },
              } = await supabase.auth.getSession()

              if (session?.user) {
                // Admin user is logged in via Supabase Auth
                setUser({
                  id: session.user.id,
                  email: session.user.email || "",
                  role: "admin",
                  name: session.user.user_metadata?.name || "Admin User",
                })
                setRole("admin")
              } else {
                setUser(null)
                setRole(null)
              }
            } else {
              setUser(null)
              setRole(null)
            }
          }
        }
      } catch (error) {
        console.error("Error checking authentication:", error)
        setUser(null)
        setRole(null)
      } finally {
        setIsLoading(false)
      }
    }

    checkUser()

    // Set up auth state change listener only if we have Supabase connection
    let subscription: { unsubscribe: () => void } | null = null

    if (hasSupabaseConnection()) {
      const { data } = supabase.auth.onAuthStateChange(async (event, session) => {
        if (event === "SIGNED_IN" && session) {
          setUser({
            id: session.user.id,
            email: session.user.email || "",
            role: "admin",
            name: session.user.user_metadata?.name || "Admin User",
          })
          setRole("admin")
        } else if (event === "SIGNED_OUT") {
          setUser(null)
          setRole(null)
          localStorage.removeItem("driver")
          localStorage.removeItem("admin")
          router.push("/")
        }
      })

      subscription = data.subscription
    }

    return () => {
      if (subscription) {
        subscription.unsubscribe()
      }
    }
  }, [router])

  const signOut = async () => {
    if (role === "admin") {
      if (hasSupabaseConnection()) {
        await supabase.auth.signOut()
      }
      localStorage.removeItem("admin")
      setUser(null)
      setRole(null)
      router.push("/")
    } else if (role === "driver") {
      localStorage.removeItem("driver")
      setUser(null)
      setRole(null)
      router.push("/")
    }
  }

  return <AuthContext.Provider value={{ user, role, isLoading, signOut }}>{children}</AuthContext.Provider>
}

export const useAuth = () => useContext(AuthContext)
