"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import * as z from "zod"
import { Eye, EyeOff, Loader2 } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { supabase, hasSupabaseConnection } from "@/lib/supabase/client"

const loginSchema = z.object({
  email: z.string().email({ message: "Please enter a valid email address" }),
  password: z.string().min(6, { message: "Password must be at least 6 characters" }),
})

type LoginValues = z.infer<typeof loginSchema>

export function AuthForm() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [showPassword, setShowPassword] = useState(false)
  const [authError, setAuthError] = useState<string | null>(null)
  const [authMode, setAuthMode] = useState<"admin" | "driver">("admin")

  const form = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: "",
    },
  })

  async function onSubmit(data: LoginValues) {
    setIsLoading(true)
    setAuthError(null)

    console.log("Login attempt:", { email: data.email, mode: authMode })

    try {
      if (authMode === "admin") {
        // For demo purposes, allow login with test credentials
        if (
          (data.email === "admin@example.com" && data.password === "password123") ||
          (data.email === "manager@example.com" && data.password === "password123")
        ) {
          console.log("Admin test login successful")
          // Mock successful login
          localStorage.setItem(
            "admin",
            JSON.stringify({
              id:
                data.email === "admin@example.com"
                  ? "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11"
                  : "b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22",
              email: data.email,
              role: "admin",
              name: data.email === "admin@example.com" ? "Admin User" : "Manager User",
            }),
          )

          // Use window.location for a hard redirect instead of router
          window.location.href = "/admin"
          return
        }

        // Only try Supabase auth if we have a connection
        if (hasSupabaseConnection()) {
          // Real Supabase Auth (would be used in production)
          const { error } = await supabase.auth.signInWithPassword({
            email: data.email,
            password: data.password,
          })

          if (error) throw error

          router.push("/admin")
          router.refresh()
        } else {
          throw new Error("Invalid credentials. Use the test accounts provided below.")
        }
      } else {
        // Driver login - for demo purposes, allow login with test credentials
        if (
          (data.email === "john.smith@example.com" && data.password === "driver123") ||
          (data.email === "sarah.johnson@example.com" && data.password === "driver123")
        ) {
          console.log("Driver test login successful")
          // Mock successful login
          const driverId = data.email === "john.smith@example.com" ? "DRV001" : "DRV002"
          const driverName = data.email === "john.smith@example.com" ? "John Smith" : "Sarah Johnson"

          localStorage.setItem(
            "driver",
            JSON.stringify({
              driver_id: driverId,
              email: data.email,
              name: driverName,
              status: "active",
            }),
          )

          // Use window.location for a hard redirect instead of router
          window.location.href = "/driver"
          return
        }

        // Only try Supabase if we have a connection
        if (hasSupabaseConnection()) {
          // Check against drivers table (would be used in production)
          const { data: driver, error } = await supabase.from("drivers").select("*").eq("email", data.email).single()

          if (error || !driver) {
            throw new Error("Invalid driver credentials")
          }

          // Store driver info in localStorage for client-side access
          localStorage.setItem("driver", JSON.stringify(driver))

          router.push("/driver")
          router.refresh()
        } else {
          throw new Error("Invalid credentials. Use the test accounts provided below.")
        }
      }
    } catch (error: any) {
      console.error("Authentication error:", error)
      setAuthError(error.message || "Failed to authenticate")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Delivery Management System</CardTitle>
        <CardDescription>Login to access your dashboard</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="admin" onValueChange={(value) => setAuthMode(value as "admin" | "driver")}>
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="admin">Admin Login</TabsTrigger>
            <TabsTrigger value="driver">Driver Login</TabsTrigger>
          </TabsList>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email</FormLabel>
                    <FormControl>
                      <Input placeholder="your.email@example.com" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Password</FormLabel>
                    <FormControl>
                      <div className="relative">
                        <Input type={showPassword ? "text" : "password"} placeholder="••••••••" {...field} />
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="absolute right-0 top-0 h-full px-3"
                          onClick={() => setShowPassword(!showPassword)}
                        >
                          {showPassword ? <EyeOff size={16} /> : <Eye size={16} />}
                          <span className="sr-only">{showPassword ? "Hide password" : "Show password"}</span>
                        </Button>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              {authError && <div className="text-sm font-medium text-destructive">{authError}</div>}
              <Button type="submit" className="w-full" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Logging in...
                  </>
                ) : (
                  "Login"
                )}
              </Button>
            </form>
          </Form>
        </Tabs>
      </CardContent>
      <CardFooter className="flex justify-center">
        <p className="text-sm text-muted-foreground">
          {authMode === "admin"
            ? "Admin access is restricted to authorized personnel only."
            : "Drivers must be registered by an admin before logging in."}
        </p>
      </CardFooter>
    </Card>
  )
}
