"use client"

import { useState } from "react"
import { Copy, Check } from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface Credential {
  email: string
  password: string
  role: string
  description: string
}

export function TestLoginCredentials() {
  const [copied, setCopied] = useState<string | null>(null)

  const adminCredentials: Credential[] = [
    {
      email: "admin@example.com",
      password: "password123",
      role: "Admin",
      description: "Full access to all features",
    },
    {
      email: "manager@example.com",
      password: "password123",
      role: "Manager",
      description: "Limited administrative access",
    },
  ]

  const driverCredentials: Credential[] = [
    {
      email: "john.smith@example.com",
      password: "driver123",
      role: "Driver",
      description: "Active driver with assigned deliveries",
    },
    {
      email: "sarah.johnson@example.com",
      password: "driver123",
      role: "Driver",
      description: "Active driver with assigned deliveries",
    },
  ]

  const copyToClipboard = (text: string, type: string) => {
    navigator.clipboard.writeText(text)
    setCopied(type)
    setTimeout(() => setCopied(null), 2000)
  }

  const handleDirectLogin = (email: string, password: string, type: "admin" | "driver") => {
    // Store the credentials in localStorage
    if (type === "admin") {
      const isAdmin = email === "admin@example.com"
      localStorage.setItem(
        "admin",
        JSON.stringify({
          id: isAdmin ? "a0eebc99-9c0b-4ef8-bb6d-6bb9bd380a11" : "b0eebc99-9c0b-4ef8-bb6d-6bb9bd380a22",
          email: email,
          role: "admin",
          name: isAdmin ? "Admin User" : "Manager User",
        }),
      )
      window.location.href = "/admin"
    } else {
      const isJohn = email === "john.smith@example.com"
      localStorage.setItem(
        "driver",
        JSON.stringify({
          driver_id: isJohn ? "DRV001" : "DRV002",
          email: email,
          name: isJohn ? "John Smith" : "Sarah Johnson",
          status: "active",
        }),
      )
      window.location.href = "/driver"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Test Login Credentials</CardTitle>
        <CardDescription>Use these credentials to test the application</CardDescription>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="admin">
          <TabsList className="grid w-full grid-cols-2 mb-4">
            <TabsTrigger value="admin">Admin Accounts</TabsTrigger>
            <TabsTrigger value="driver">Driver Accounts</TabsTrigger>
          </TabsList>

          <TabsContent value="admin" className="space-y-4">
            {adminCredentials.map((cred, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 border rounded-md"
              >
                <div>
                  <div className="font-medium">{cred.role}</div>
                  <div className="text-sm text-muted-foreground">{cred.description}</div>
                </div>
                <div className="flex flex-col gap-2 mt-2 sm:mt-0">
                  <div className="flex items-center gap-2">
                    <code className="relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm">
                      {cred.email}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => copyToClipboard(cred.email, `admin-email-${index}`)}
                    >
                      {copied === `admin-email-${index}` ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                      <span className="sr-only">Copy email</span>
                    </Button>
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm">
                      {cred.password}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => copyToClipboard(cred.password, `admin-password-${index}`)}
                    >
                      {copied === `admin-password-${index}` ? (
                        <Check className="h-3 w-3" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                      <span className="sr-only">Copy password</span>
                    </Button>
                  </div>
                  <Button
                    size="sm"
                    className="mt-2"
                    onClick={() => handleDirectLogin(cred.email, cred.password, "admin")}
                  >
                    Login as {cred.role}
                  </Button>
                </div>
              </div>
            ))}
          </TabsContent>

          <TabsContent value="driver" className="space-y-4">
            {driverCredentials.map((cred, index) => (
              <div
                key={index}
                className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-3 border rounded-md"
              >
                <div>
                  <div className="font-medium">{cred.role}</div>
                  <div className="text-sm text-muted-foreground">{cred.description}</div>
                </div>
                <div className="flex flex-col gap-2 mt-2 sm:mt-0">
                  <div className="flex items-center gap-2">
                    <code className="relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm">
                      {cred.email}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => copyToClipboard(cred.email, `driver-email-${index}`)}
                    >
                      {copied === `driver-email-${index}` ? (
                        <Check className="h-3 w-3" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                      <span className="sr-only">Copy email</span>
                    </Button>
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="relative rounded bg-muted px-[0.3rem] py-[0.2rem] font-mono text-sm">
                      {cred.password}
                    </code>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="h-6 w-6"
                      onClick={() => copyToClipboard(cred.password, `driver-password-${index}`)}
                    >
                      {copied === `driver-password-${index}` ? (
                        <Check className="h-3 w-3" />
                      ) : (
                        <Copy className="h-3 w-3" />
                      )}
                      <span className="sr-only">Copy password</span>
                    </Button>
                  </div>
                  <Button
                    size="sm"
                    className="mt-2"
                    onClick={() => handleDirectLogin(cred.email, cred.password, "driver")}
                  >
                    Login as {cred.role}
                  </Button>
                </div>
              </div>
            ))}
          </TabsContent>
        </Tabs>

        <div className="mt-4 text-sm text-muted-foreground">
          <p>
            Note: In a production environment, you would need to set up proper authentication with hashed passwords.
          </p>
        </div>
      </CardContent>
    </Card>
  )
}
